Extract to folder first before running.
Good luck and have fun :)